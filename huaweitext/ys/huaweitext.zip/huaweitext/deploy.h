#ifndef __ROUTE_H__
#define __ROUTE_H__

#include "lib_io.h"
#define MAXN 3000+2

void deploy_server(char * graph[MAX_EDGE_NUM], int edge_num, char * filename);

	

#endif
